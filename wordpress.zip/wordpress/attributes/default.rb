# The root password for MySQL
default['wordpress']['db_pass'] = 'MySQLP4ssw0rd$'
# The name of the WordPress database
default['wordpress']['db_name'] = 'wordpress'
# The default username for the WordPress database
default['wordpress']['db_user'] = 'wp_user'
