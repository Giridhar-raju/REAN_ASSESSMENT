name             'wordpress'
maintainer       ''
maintainer_email ''
license          ''
description      'Installs/Configures wordpress'
long_description 'Installs/Configures wordpress'
version          '0.1.0'

