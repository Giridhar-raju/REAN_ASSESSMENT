package 'httpd24' do
  action :install
end

# Enable start on boot and start Apache
service 'httpd' do
  action [:enable, :start]
end
