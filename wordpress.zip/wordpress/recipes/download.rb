ruby_block "download_wordpress" do
  block do
    require 'fileutils'
    FileUtils.cd '/var/www/html'
    system 'curl -o latest.tar.gz https://wordpress.org/latest.tar.gz'
    system 'tar xzvf latest.tar.gz --strip-components=1 && rm latest.tar.gz'
    FileUtils.cp('/var/www/html/wp-config-sample.php','/var/www/html/wp-config.php')
  end
  not_if { ::File.exist?(File.join('/var/www/html', 'wp-settings.php')) }
  action :create
end
