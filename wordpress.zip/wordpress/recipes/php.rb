# Install PHP and its modules
%w{php70 php70-mysqlnd php70-mbstring.x86_64 php70-zip.x86_64}.each do |pkg|
  package pkg do
    action :install
    notifies :reload, 'service[httpd]', :immediately
  end
end

ruby_block "download_phpMyAdmin" do
  block do
    require 'fileutils'
    FileUtils.cd '/var/www/html'
    system 'wget https://www.phpmyadmin.net/downloads/phpMyAdmin-latest-all-languages.tar.gz'
    system 'mkdir phpMyAdmin && tar -xvzf phpMyAdmin-latest-all-languages.tar.gz -C phpMyAdmin --strip-components 1 && rm -rf phpMyAdmin-latest-all-languages.tar.gz'
  end
  action :create
end
