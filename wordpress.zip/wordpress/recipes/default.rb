#
# Cookbook Name:: wordpress
# Recipe:: default
#
# Copyright (C) 2019 
#
# 
#
include_recipe 'wordpress::apache'
include_recipe 'wordpress::php'
include_recipe 'wordpress::mysql'
include_recipe 'wordpress::download'
